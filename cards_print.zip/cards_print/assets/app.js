 
var card_name =""
// function newText(){

//     let params ={
//         active:true,
//         currentWindow:true
//     }
//     chrome.tabs.query(params,gotTabs);
//     function gotTabs(tabs){
//         // let message = userinput.value()
//         let msg = {
//             text: "hello"
//         }
//         chrome.tabs.sendMessage(tabs[0].id, msg,  function (response) {
//         console.dir(response.data);
//         card_name = response.data.receipt
//         document.getElementById('total_cards').innerHTML = response.data.cards.length
//         document.getElementById('total_amount').innerHTML = '$'+response.data.total_amount
//         document.getElementById('denomination').innerHTML ='$'+response.data.denomination
//         document.getElementById('receipt').innerHTML =response.data.receipt
//         document.getElementById('main_cards_no').innerHTML = response.data.cards.length
//         document.getElementById('cashier').innerHTML = response.data.cashier

//          var row = document.getElementById('cards')

//           response.data.cards.forEach(card => {
//                row.innerHTML += ' <div class="col-md-3"> <div class="top d-flex"> <span class="pin_text">PIN:</span> <span class="pin">'+card.card_number.replace(/ +/g, "")+'</span> <span class="price">$'+response.data.denomination+'</span> </div><div class="bottom d-flex"> <span class="serial_text">Serial No:</span> <span class="serial">'+card.serial_number.replace(/ +/g, "")+'</span> </div></div>'
//           });
        
//     } )

//       console.log('send')
//     }
// }
// newText()


chrome.runtime.onMessage.addListener(
    function(message, sender, sendResponse) {
        console.log("zvaita")
        setDom(message)
    }
);

function setDom(message){
  console.log(message.cards)

    card_name = message.data.receipt

    // document.getElementById('total_cards').innerHTML = message.data.cards.length
    // document.getElementById('total_amount').innerHTML = '$'+message.data.total_amount
    // document.getElementById('denomination').innerHTML ='$'+message.data.denomination
    // document.getElementById('receipt').innerHTML =message.data.receipt
    // document.getElementById('main_cards_no').innerHTML = message.data.cards.length
    // document.getElementById('cashier').innerHTML = message.data.cashier

    var row = document.getElementById('cards')
    console.log(row)
    message.data.cards.forEach(card => {
         row.innerHTML += ' <div class="col-md-3"> <div class="top d-flex"> <span class="pin_text">PIN:</span> <span class="pin">'+card.card_number.replace(/ +/g, "")+'</span> <span class="price">$'+message.data.denomination+'</span> </div><div class="bottom d-flex"> <span class="serial_text">Serial No:</span> <span class="serial">'+card.serial_number.replace(/ +/g, "")+'</span> </div></div>'
    });
}

document.getElementById("myBtn").addEventListener("click", function() {
   print()
  });
function print(){
    const cards = this.document.getElementById("cards");
       
        var opt = {
            margin: 0,
            filename:'cards' + card_name+'.pdf',
            image: { type: 'jpeg', quality: 2 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
        };
        html2pdf().from(cards).set(opt).save();
}
